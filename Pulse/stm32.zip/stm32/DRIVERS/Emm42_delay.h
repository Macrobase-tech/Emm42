#ifndef __Emm42_DELAY_H
#define __Emm42_DELAY_H

#include "stm32f10x.h"

void Emm42_delay_ms(uint32_t u32Cnt);

#endif
